#!/usr/bin/env bash
set -uo pipefail
root=/workspace/kam-ci-current
out=/workspace/kam-slice-evidence/published
mkdir -p "$out"
cd "$out"
export PATH=/workspace/kam-cross-tools/root/usr/bin:$PATH
export LD_LIBRARY_PATH=/workspace/kam-cross-tools/root/usr/lib/x86_64-linux-gnu
export FPC_ANDROID=/workspace/kam-ci-evidence/fpc-android-configured
export FPC_ANDROID_UNITS=/workspace/kam-fpc-android/lib/fpc/3.2.2/units/aarch64-android
export FPC_HOST=/workspace/kam-ci-evidence/fpc-host
export LAZUTILS_SOURCE=/workspace/kam-lazarus-source/components/lazutils
export LCL_SOURCE=/workspace/kam-lazarus-source/lcl
{
  date -u
  git -C "$root" rev-parse HEAD HEAD^{tree}
  git -C "$root" status --porcelain
  git -C "$root/src/ext/pascalscript_submodule" rev-parse HEAD
  git -C /workspace/kam-fpc-source rev-parse HEAD
  git -C /workspace/kam-lazarus-source rev-parse HEAD
  "$FPC_ANDROID" -Paarch64 -Tandroid -iV -iTP -iTO
  sha256sum "$root/android-port/experiments/prepare-pascalscript-fpc.py" /workspace/kam-cross-tools/binutils.deb
} > provenance.log
python3 "$root/android-port/experiments/prepare-pascalscript-fpc.py" "$root/src/ext/pascalscript_submodule/Source" "$out/ps-overlay" > prepare-overlay.log 2>&1 || exit 1
export PS_OVERLAY="$out/ps-overlay"
export PORT_BUILD_DIR="$out/overlay-units"
export PORT_TARGETS='src/media/KM_BassAndroid.pas src/media/KM_Music.pas src/game/KM_GameAudioState.pas src/utils/KM_TextClipboard.pas android-port/host/pascal/KM_AndroidTextClipboard.pas android-port/host/pascal/kamprobe.lpr src/controls/KM_ControlsBase.pas src/controls/KM_ControlsEdit.pas src/game/KM_Game.pas'
bash "$root/android-port/experiments/compile-game-android.sh" > overlay.log 2>&1
printf 'overlay_exit=%s\n' "$?" > status.log
unset PS_OVERLAY
PORT_BUILD_DIR="$out/baseline-units" PORT_TARGETS=src/game/KM_Game.pas bash "$root/android-port/experiments/compile-game-android.sh" > baseline.log 2>&1
printf 'baseline_exit=%s\n' "$?" >> status.log
for test in controls-input game-messages fog-state platform-services pascal-script; do
  PORT_TEST_DIR="$out/test-$test" bash "$root/android-port/tests/test-$test-linux.sh" > "test-$test.log" 2>&1
  printf '%s_exit=%s\n' "$test" "$?" >> status.log
done
/workspace/kam-tools/actionlint -shellcheck='' "$root"/.github/workflows/*.yml > actionlint.log 2>&1
printf 'actionlint_exit=%s\n' "$?" >> status.log
mkdir -p java
/workspace/kam-tools/jdk-17.0.17+10/bin/javac -source 8 -target 8 -classpath /workspace/kam-tools/android-platform/android-35/android.jar -d java $(find "$root/android-port/host/app/src/main/java" "$root/android-port/host/app/src/androidTest/java" -name '*.java') > javac.log 2>&1
printf 'javac_exit=%s\n' "$?" >> status.log
git -C "$root" status --porcelain > checkout-status-after.log
cat status.log
