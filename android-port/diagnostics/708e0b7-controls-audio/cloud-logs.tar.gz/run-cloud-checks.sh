#!/usr/bin/env bash
set -uo pipefail
root=/workspace/kam-ci-current
out=/workspace/kam-audio-evidence/final
mkdir -p "$out"
cd "$out"
export PATH=/workspace/kam-cross-tools/root/usr/bin:$PATH
export LD_LIBRARY_PATH=/workspace/kam-cross-tools/root/usr/lib/x86_64-linux-gnu
export FPC_ANDROID=/workspace/kam-ci-evidence/fpc-android-configured
export FPC_ANDROID_UNITS=/workspace/kam-fpc-android/lib/fpc/3.2.2/units/aarch64-android
export FPC_HOST=/workspace/kam-ci-evidence/fpc-host
export LAZUTILS_SOURCE=/workspace/kam-lazarus-source/components/lazutils
export LCL_SOURCE=/workspace/kam-lazarus-source/lcl
export FPC_SOURCE=/workspace/kam-fpc-source
{
 date -u
 git -C "$root" rev-parse HEAD HEAD^{tree}
 git -C "$root" status --porcelain
 git -C "$root/src/ext/pascalscript_submodule" rev-parse HEAD
 git -C "$FPC_SOURCE" rev-parse HEAD
 git -C /workspace/kam-lazarus-source rev-parse HEAD
 "$FPC_ANDROID" -Paarch64 -Tandroid -iV -iTP -iTO
 /workspace/kam-cross-tools/root/usr/bin/aarch64-linux-gnu-as --version | head -1
 /workspace/kam-tools/jdk-17.0.17+10/bin/javac -version
 sha256sum "$root/android-port/experiments/prepare-pascalscript-fpc.py" /workspace/kam-cross-tools/binutils.deb
 cat /workspace/kam-ci-evidence/fpc-android-configured /workspace/kam-ci-evidence/fpc-host
} > provenance.log 2>&1
python3 "$root/android-port/experiments/prepare-pascalscript-fpc.py" "$root/src/ext/pascalscript_submodule/Source" "$out/ps-overlay" > prepare-overlay.log 2>&1 || exit 1
export PS_OVERLAY="$out/ps-overlay"
export PORT_BUILD_DIR="$out/overlay-units"
: > status.log
for target in src/controls/KM_ControlsTypes.pas src/utils/KM_UtilsExt.pas src/media/KM_AudioSession.pas src/media/KM_OpenALBackend.pas src/media/KM_Sound.pas android-port/host/pascal/kamprobe.lpr src/controls/KM_ControlsList.pas src/controls/KM_ControlsBase.pas src/controls/KM_ControlsEdit.pas src/game/KM_Game.pas; do
 PORT_TARGETS="$target" bash "$root/android-port/experiments/compile-game-android.sh" > "overlay-$(basename "$target").log" 2>&1
 printf '%s_exit=%s\n' "$target" "$?" >> status.log
done
unset PS_OVERLAY
PORT_BUILD_DIR="$out/baseline-units" PORT_TARGETS=src/game/KM_Game.pas bash "$root/android-port/experiments/compile-game-android.sh" > baseline.log 2>&1
printf 'unpatched_KM_Game_exit=%s\n' "$?" >> status.log
for test in audio-session controls-input game-messages fog-state platform-services pascal-script game-options game-presentation-port map-header font-types terrain-types; do
 PORT_TEST_DIR="$out/test-$test" bash "$root/android-port/tests/test-$test-linux.sh" > "test-$test.log" 2>&1
 printf '%s_exit=%s\n' "$test" "$?" >> status.log
done
PORT_TEST_DIR="$out/test-jni-map" bash "$root/android-port/host/tests/linux-jni-map.sh" > test-jni-map.log 2>&1
printf 'jni-map_exit=%s\n' "$?" >> status.log
mkdir -p openal
ln -sf /usr/lib/x86_64-linux-gnu/libopenal.so.1 openal/libopenal.so
LD_LIBRARY_PATH="$out/openal:$LD_LIBRARY_PATH" PORT_TEST_DIR="$out/openal" bash "$root/android-port/tests/test-openal-session-linux.sh" > test-openal.log 2>&1
printf 'openal_linux_null_exit=%s\n' "$?" >> status.log
mkdir -p ffi-lib
ln -sf /usr/lib/x86_64-linux-gnu/libffi.so.8 ffi-lib/libffi.so
export LIBFFI_LIB_DIR="$out/ffi-lib"
PORT_TEST_DIR="$out/test-ffi" bash "$root/android-port/tests/test-ffi-abi-linux.sh" > test-ffi.log 2>&1
printf 'ffi_exit=%s\n' "$?" >> status.log
FFI_FIXED_SOURCE="$out/test-ffi/fixed" PORT_TEST_DIR="$out/test-ps-compat" bash "$root/android-port/tests/test-pascalscript-compat-linux.sh" > test-ps-compat.log 2>&1
printf 'ps_compat_exit=%s\n' "$?" >> status.log
/workspace/kam-tools/actionlint -shellcheck='' "$root"/.github/workflows/*.yml > actionlint.log 2>&1
printf 'actionlint_exit=%s\n' "$?" >> status.log
mkdir -p java
/workspace/kam-tools/jdk-17.0.17+10/bin/javac -source 8 -target 8 -classpath /workspace/kam-tools/android-platform/android-35/android.jar -d java $(find "$root/android-port/host/app/src/main/java" "$root/android-port/host/app/src/androidTest/java" -name '*.java') > javac.log 2>&1
printf 'javac_exit=%s\n' "$?" >> status.log
readelf -h overlay-units/KM_AudioSession.o overlay-units/KM_OpenALBackend.o overlay-units/KM_ControlsTypes.o > elf-headers.log 2>&1
printf 'elf_headers_exit=%s\n' "$?" >> status.log
git -C "$root" status --porcelain > checkout-status-after.log
cat status.log
