#!/bin/sh
DoExitAsm ()
{ echo "An error occurred while assembling $1"; exit 1; }
DoExitLink ()
{ echo "An error occurred while linking $1"; exit 1; }
echo Linking /workspace/kam-ci-current/android-port/host/pascal/libkamprobe.so
OFS=$IFS
IFS="
"
/workspace/kam-cross-tools/root/usr/bin/aarch64-linux-gnu-ld.bfd -z max-page-size=0x1000 -z common-page-size=0x1000 -z noexecstack -z now -z relro --build-id --gc-sections -L. -T link15835.res -o /workspace/kam-ci-current/android-port/host/pascal/libkamprobe.so -shared -soname libkamprobe.so
if [ $? != 0 ]; then DoExitLink /workspace/kam-ci-current/android-port/host/pascal/libkamprobe.so; fi
IFS=$OFS
