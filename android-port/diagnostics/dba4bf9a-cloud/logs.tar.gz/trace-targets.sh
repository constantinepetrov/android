#!/usr/bin/env bash
set -uo pipefail
cd /workspace/kam-ci-current
export PATH=/workspace/kam-cross-tools/root/usr/bin:$PATH
export LD_LIBRARY_PATH=/workspace/kam-cross-tools/root/usr/lib/x86_64-linux-gnu
compiler=/workspace/kam-ci-evidence/fpc-android-configured
units=$(find /workspace/kam-fpc-android -type d -path '*/units/aarch64-android' -print -quit)
paths=()
while IFS= read -r -d '' path; do paths+=("-Fu$path" "-Fi$path"); done < <(find "$PWD/src" -type d -print0)
for mode in overlay baseline; do
  overlay=()
  if [ "$mode" = overlay ]; then overlay=("-Fu/workspace/kam-ci-evidence/ps-overlay" "-Fi/workspace/kam-ci-evidence/ps-overlay"); fi
  for target in KM_ControlsBase KM_Game; do
    if [ "$target" = KM_Game ]; then source=src/game/KM_Game.pas; else source=src/controls/KM_ControlsBase.pas; fi
    out=/workspace/kam-ci-evidence/trace-$mode-$target
    mkdir -p "$out"
    command=("$compiler" -Paarch64 -Tandroid -XPaarch64-linux-gnu- -Mdelphi -dDBG_SKIP_SECURE_AUTH -B -Cn -vu "-Fi$PWD" "-Fu$units/*" "${overlay[@]}" -Fu/workspace/kam-lazarus-source/components/lazutils -Fi/workspace/kam-lazarus-source/components/lazutils "-Fu$PWD/android-port/pascal" "-Fi$PWD/android-port/pascal" -Fu/workspace/kam-lazarus-source/lcl -Fi/workspace/kam-lazarus-source/lcl/include "${paths[@]}" "-FU$out" "$PWD/$source")
    printf '%q ' "${command[@]}" > "$out.command"
    printf '\n' >> "$out.command"
    "${command[@]}" > "$out.log" 2>&1
    printf '%s %s exit=%s\n' "$mode" "$target" "$?"
  done
done
