#!/usr/bin/env bash
set -euo pipefail
cd /workspace/kam-ci-current
export PATH=/workspace/kam-cross-tools/root/usr/bin:$PATH
export LD_LIBRARY_PATH=/workspace/kam-cross-tools/root/usr/lib/x86_64-linux-gnu
export FPC_ANDROID=/workspace/kam-ci-evidence/fpc-android-configured
export FPC_ANDROID_UNITS=$(find /workspace/kam-fpc-android -type d -path '*/units/aarch64-android' -print -quit)
export LAZUTILS_SOURCE=/workspace/kam-lazarus-source/components/lazutils
export LCL_SOURCE=/workspace/kam-lazarus-source/lcl
out=/workspace/kam-ci-evidence
{
  date -u
  git rev-parse HEAD HEAD^{tree}
  git status --porcelain
  git -C src/ext/pascalscript_submodule rev-parse HEAD
  git -C /workspace/kam-fpc-source rev-parse HEAD
  git -C /workspace/kam-lazarus-source rev-parse HEAD
  "$FPC_ANDROID" -iV -iTP -iTO
  sha256sum /workspace/kam-cross-tools/binutils.deb
} > "$out/provenance.log"
python3 android-port/experiments/prepare-pascalscript-fpc.py src/ext/pascalscript_submodule/Source "$out/ps-overlay" > "$out/prepare-overlay.log" 2>&1
mkdir -p "$out/ps-units"
for unit in uPSRuntime.pas uPSCompiler.pas; do
  "$FPC_ANDROID" -Paarch64 -Tandroid -XPaarch64-linux-gnu- -Mdelphi -B -Cn -Fi"$PWD" "-Fu$FPC_ANDROID_UNITS/*" "-Fu$out/ps-overlay" "-Fi$out/ps-overlay" "-FU$out/ps-units" "$out/ps-overlay/$unit"
done > "$out/ps-overlay-build.log" 2>&1
set +e
PS_OVERLAY="$out/ps-overlay" PORT_BUILD_DIR="$out/overlay-units" bash android-port/experiments/compile-game-android.sh > "$out/client-overlay.log" 2>&1
overlay_status=$?
PORT_BUILD_DIR="$out/baseline-units" bash android-port/experiments/compile-game-android.sh > "$out/client-baseline.log" 2>&1
baseline_status=$?
printf 'overlay_exit=%s\nbaseline_exit=%s\n' "$overlay_status" "$baseline_status" > "$out/compiler-status.log"
cat "$out/compiler-status.log"
